#ifndef __POKERAI_FLOP_H__
#define __POKERAI_FLOP_H__

void MakeDecisionFlop(PokerAI *ai);


#endif
