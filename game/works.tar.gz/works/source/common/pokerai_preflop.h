#ifndef __POKERAI_PREFLOP_H__
#define __POKERAI_PREFLOP_H__

void MakeDecisionPreflop(PokerAI *ai);
//int GetPreflopValue(int *hand);
//float GetPreflopPower(int *hand);

#endif
