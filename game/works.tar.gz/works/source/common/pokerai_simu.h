#ifndef __POKERAI_SIMU_H__
#define __POKERAI_SIMU_H__

double GetWinProbability(PokerAI *ai);


#endif
