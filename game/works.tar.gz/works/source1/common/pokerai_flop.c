#include "pokerai.h"
#include "pokerai_aggress.h"

//#include "pokerai_flop.h"


// 配置
//int cfClassStragetRaiseForStart_len = 3;	//三级 [1] [2] [3]
//int cfClassStragetRaiseForStart[] = {-1, 1, 1, 6, -1};



//static int is_print_one_time_info = 1;
//==========================================================================================================================
    
static   
int myrand(int a, int b) {
	if (a == b) return 0;
	if (a > b) {
		int t = a;
		a = b;
		b = t;
	}	
	return (rand()%(b-a) + a);
}

static
int GetFlopStraget(int round) {
	
	int stg = 1;
	if (round <= myrand(90,100)) {
		stg = 1;
	} else {
		stg = -1;
	}
	return stg;
}

static
void SetBetOrCall(PokerAI *ai, int a, int b, int amount) {
	int th = rand()%100;
	if (a+b == 0) {
		a = 50;
		b = 50;
	}
	a = 100*a/(a+b);
	b = 100-a;
	if (th < a) {
		SetBet(amount);
	} else {
		SetCall();
	}
}

static
void SetCallOrFold(PokerAI *ai, int a, int b, int amount) {
	int th 	= rand()%100;
	int isSB= ((ai->game.isSpecialPos == 5)?(1):(0));
	
	if (a+b == 0) {
		a = 50;
		b = 50;
	}	
	if (isSB) {
		//小盲注概率加成
		a = 2*a;
	}
	a = 100*a/(a+b);
	b = 100-a;	
	if (th < a) {
		SetCall();
	} else {
		SetFold();
	}
}

//==========================================================================================================================

static 
int IsBetterClassFlopWinprob(int pwr, int class) {	
	int aggWinprobClass[5]   = {100, 8, 7.7, 7, 6};
	if (pwr >= aggWinprobClass[class]) {
		return 1;
	} else {
		return 0;
	}
}

/*
static
int StackProtection(PokerAI *ai, VarTran_t h, int wpBet) {
	// stack protection - check if we need
	int isNeedProtection = 1;		
	if (h.stack < 2*40) 			{isNeedProtection = 0;}
	if (h.wp >= 0.9) 				{isNeedProtection = 0;}
	if (ai->action.bluff == true) 	{isNeedProtection = 0;}	
	
	if (!isNeedProtection) {
		return wpBet;
	}
	
	// stack protection - runs
	if (h.wp > 0.9) {
		;
	} else if (h.wp >= 0.85) {
		if (wpBet > h.stack / 2 && h.money < (5*40)) {
			wpBet = h.stack / 2;
		}
	} else {
		if (wpBet > h.stack / 4 && h.money < (10*40)) {
			wpBet = h.stack / 4;
		}
	}
	
	return wpBet;
}
*/

static
void StragetFlopCommon(PokerAI *ai, VarTran_t h) {
    int randnum = rand() % 100;
    int act 	= -1;		// 动作：-1 fold; 0 call; >0 raise
	int maxBet 	= 0;		// 每种概率最大总投入
	
    if (h.eg < 0.8 && h.wp < 0.8) 
    {                
        act  	= -1;        		// -1 fold  
        maxBet 	= -1;
    }
    else if ((h.eg < 1.0 && h.wp < 0.85) || h.wp < 0.1)
    {
        act 	= -1;        		// -1 fold
        
    }
    else if ((h.eg < 1.3 && h.wp < 0.9) || h.wp < 0.5)
    {
        if (randnum < 60 || h.wp < 0.5) {
            act  = 0;					//  0 call            
        } else {
            act  = 1;			 	//    raise
        }
    }
    else if (h.wp < 0.95 || ai->game.communitysize < 4)
    {
        if (randnum < 30) {
            act  = 0;					//  0 call            
        } else {
            act  = 1;				//    raise
        }
    }
    else if (h.wp >= 0.95)
    {
    	//huge chance of winning, okay to bet more than "wpBet"
        act  = 1;        
    } else {
        act  = 1;					//    raise   	
    }
    
    ai->action.bluff = 0;
	
	//stack protect && raise jetton
	int wpCallJetton = -1;						// 这次的加注值
	if (act > 0) {
		if (h.wp >= 0.95) {
			//牌越少越强
			if (ai->game.communitysize == 3) {
				wpCallJetton = MIN(h.stack/2, 10*h.BB);
			} else if (ai->game.communitysize == 4) {
				wpCallJetton = MIN(h.stack/2, 9*h.BB);
			} else if (ai->game.communitysize == 5) {
				wpCallJetton = MIN(h.stack/3, 8*h.BB);
			} else if (ai->game.communitysize == 6) {
				wpCallJetton = MIN(h.stack/3, 7*h.BB);
			} else if (ai->game.communitysize == 7) {
				wpCallJetton = MIN(h.stack/4, 6*h.BB);
			} else {
				wpCallJetton = MIN(h.stack/4, 5*h.BB);
			}
			maxBet = h.stack;
			
		} else if (h.wp >= 0.9) {
			wpCallJetton = MIN(h.stack/3, 8*h.BB);
			maxBet = h.stack;
		} else if (h.wp >= 0.85) {
			wpCallJetton = MIN(h.stack/4, 6*h.BB);
			maxBet = h.stack;
		} else if (h.wp >= 0.8) {
			//call
			wpCallJetton = 0;
			maxBet = h.current_bet + MAX(h.stack/4, 5*h.BB);
		} else if (h.wp >= 0.7) {
			//call
			wpCallJetton = 0;
			maxBet = h.current_bet + MAX(h.stack/5, 4*h.BB);			
		} else {
			//fold
			wpCallJetton = -1;
			maxBet = 0;
		}
	} else if (act == 0) {
		// call
		wpCallJetton = 0;
		maxBet = 0;
	} else {
		//fold
		wpCallJetton = -1;
		maxBet = 0;
	}
		
	// 下注
	if (wpCallJetton > 0) {
		if (maxBet > h.current_bet + h.raise_amount + h.call_amount) {
			SetBetOrCall(ai, 80, 20, wpCallJetton);
		} else if (maxBet > h.current_bet + h.call_amount){
			SetCallOrFold(ai, 90, 10, 0);
		} else {
			SetCallOrFold(ai, 80, 20, 0);
		}
	} else if (wpCallJetton == 0) {
		if (maxBet > h.current_bet + h.call_amount){
			SetCallOrFold(ai, 90, 10, 0);
		} else {
			SetCallOrFold(ai, 80, 20, 0);
		}		
	} else {
		SetFold();
	}
		
		
	// 陷阱
	// if >= 0.9 一直raise
	// if >= 0.8 一次raise 一次call
	if (IsBet() && h.wp >= 0.80) {		
		if (h.raise_no_c || (h.raise_no_c == 0 && h.raise_no == 1)) {
			SetCall();
		}
	}
	
	//TODO OprActionProtect
	if (IsBet() || IsAllin()) {
		
		if (h.current_bet + h.call_amount < maxBet) {
			SetCallOrFold(ai, 80, 20, 0);
		} else if (h.current_bet + h.call_amount + h.raise_amount > maxBet) {
			SetFold();
		}
	}
	if (IsCall()) {
		if (h.current_bet + h.call_amount > maxBet) {
			SetFold();
		}		
	}
	// end protect
}

void MakeDecisionFlop(PokerAI *ai)
{

	VarTran_t h 	= VarTran(ai);	
	int       stg   = GetFlopStraget(h.round);	

	MemcpyAction(&(ai->action_last), &(ai->action));

	switch (stg) {
	case 1:
		StragetFlopCommon(ai, h);
		break;
	default:
		StragetFlopCommon(ai, h);
		break;
	}    	
	
	/*
    // All in ... !!!!!!
    if (h.wp >= 0.97) {
    	ai->action.type = ACTION_ALL_IN;
    } else if (h.wp >= 0.95 && h.allin_no_bf) {
    	// 如果前面没有人all_in 那么牌不是最牛逼也可以率先all_in
    	ai->action.type = ACTION_ALL_IN;
    }
    */
    // 钱少的时候在preflop阶段all in赢面才大，在这里all in机会很小
    // TODO
/*
	// call的值不能超过最大可下注值，没有下面的判断就可能call all_in 一盘输光
	// 如果money还有不少的时候，不必fold
	// 投入太大的时候，也不可能收手，只能搏一把，也就是说current_bet不大是call转fold的必要条件
	if (h.money < 25*40 && wpBet < 0 && h.current_bet < h.stack/2) {
		SetFold();
	}
*/  
	OprBeforAgg(ai);
	
	Aggress_t agg;	
	SetAggressStruct(&agg, 3);
	GetAggressLevel(&agg, ai, h);
	SetAggressAction(&agg, ai, h, IsBetterClassFlopWinprob);
    
    RecordStat(ai);

    //h.my_pos = agg.my_pos;
	PrintDebugAI(ai, h, 1, 3);
}


