#include "pokerai.h"
#include "pokerai_aggress.h"

//#include "pokerai_preflop.h"


// 配置
//int cfClassStragetPreflopCommon_len = 4;	//三级 [1] [2] [3] [4]
float cfClassStragetPreflopCommon_init[] = {-1, 1, 2, 4, 6, -1};
float cfClassStragetPreflopCommon[] = {-1, -1, -1, -1, -1, -1};
//static int cfClassStragetPreflopCommon_OnceFlag = 0;


//==========================================================================================================================
    
static   
int myrand(int a, int b) {
	if (a == b) return 0;
	if (a > b) {
		int t = a;
		a = b;
		b = t;
	}	
	return (rand()%(b-a) + a);
}

static
int GetCurrentStraget(int round) {
	
	int stg = 1;
	int mod = (int)(round / 60);
	if (mod%2 == 0) {
		stg = 1;
	} else {
		stg = 1;
	}
	return stg;
}

static
void SetBetOrCall(PokerAI *ai, int a, int b, int amount) {
	int th = rand()%100;
	if (a+b == 0) {
		a = 50;
		b = 50;
	}
	a = 100*a/(a+b);
	b = 100-a;
	if (th < a) {
		SetBet(amount);
	} else {
		SetCall();
	}
}

static
void SetCallOrFold(PokerAI *ai, int a, int b, int amount) {
	int th 	= rand()%100;
	int isSB= ((ai->game.isSpecialPos == 5)?(1):(0));
	
	if (a+b == 0) {
		a = 50;
		b = 50;
	}	
	if (isSB) {
		//小盲注概率加成
		a = 2*a;
	}
	a = 100*a/(a+b);
	b = 100-a;	
	if (th < a) {
		SetCall();
	} else {
		SetFold();
	}
}

//==========================================================================================================================

static
void rand_cfClassStragetPreflopCommon()
{	
	cfClassStragetPreflopCommon[0] = cfClassStragetPreflopCommon_init[0];							//--
	cfClassStragetPreflopCommon[1] = cfClassStragetPreflopCommon_init[1];							//1
	cfClassStragetPreflopCommon[2] = cfClassStragetPreflopCommon_init[2] + (float)(rand()%1)/2;		//2-2.5
	cfClassStragetPreflopCommon[3] = cfClassStragetPreflopCommon_init[3] + (rand()%2);				//4-5
	cfClassStragetPreflopCommon[4] = cfClassStragetPreflopCommon_init[4] + (rand()%2);				//6-7
	cfClassStragetPreflopCommon[5] = cfClassStragetPreflopCommon_init[5];
	/*
	for (int i = 0; i < 5; i++) {
		printf("%5.2f\t", cfClassStragetPreflopCommon[i]);
	}
	printf("\n");
	*/
}

static
int IsMinimunHold_Mofang(PokerAI *ai, VarTran_t h) {
	int ret = 0;
	int c1, c2;
	float grp = GetPreflopGroup(ai->game.hand);
	
	if (ai->game.hand[0]>ai->game.hand[1]) {
		c1 = ai->game.hand[0];
		c2 = ai->game.hand[1];
	} else {
		c1 = ai->game.hand[1];
		c2 = ai->game.hand[0];
	}

    int c1val  = (c1 - 1) / 4;
    int c2val  = (c2 - 1) / 4;
    int c1suit = (c1 - 1) % 4;
    int c2suit = (c2 - 1) % 4;    

	if (grp <= 7 && c1val == 12) {
		// 7以上的Ax
		ret = 1;
	}
	if (grp <= 6 && c1val-1 == c2val && c1suit == c2suit) {
		// 6以上cs
		ret = 1;
	}
	if (grp <= 5 && c1val-1 == c2val) {
		// 5以上co
		ret = 1;
	}		
    if (c1val == c2val && c1val >= 7) {
    	// 一对9以上
        ret = 1;
    }          

    return ret;	
}

static
int IsMinimunHold_Me(PokerAI *ai, VarTran_t h) {
	int ret = 0;
	if (h.grp <= cfClassStragetPreflopCommon[4]) {
		ret = 1;
	}
	return ret;
}

static
int StragetPreflopCommon(PokerAI *ai, VarTran_t h, int (*CanEntry)(PokerAI *ai, VarTran_t h)) {
	//int BB0 = myrand(0.1*h.BB,0.3*h.BB);
	int BB1 = myrand(0.8*h.BB,1.5*h.BB);
	int BB2 = myrand(1.4*h.BB,2.1*h.BB);
	int BB3 = myrand(1.8*h.BB,2.5*h.BB);
	int bet = 0;
	int tmc = 0;//>=h.raise_no_c;
	int tma = 0;//>=h.raise_no;
	int rra = 0;//re-raise abalable
	int maxBet = 0;
	
	rand_cfClassStragetPreflopCommon();		

	if (!CanEntry(ai, h)) {
		SetFold();
		return -1;
	}
	// 不加入局
	/*
	if (h.grp > cfClassStragetPreflopCommon[4]) {	
		SetFold();	
		return -1;
	}
	if (!MoFang_IsMinimunHold(ai->game.hand)) {
		SetFold();
		return -1;
	}
	*/	
	// 更新数据	
	if (h.grp <= cfClassStragetPreflopCommon[1]) {
		puts("\t\t\t\t\t\t++++++++++grp1++++++++++");
		bet = BB3;
		tmc = 2;
		tma = 10;
		rra = 1;
		maxBet = h.stack;
	} else if (h.grp <= cfClassStragetPreflopCommon[2]) {
		bet = BB2;
		tmc = 1;
		tma = 7;
		rra = 1;
		maxBet = MAX(h.stack/1.75, 20*BB3);
	} else if (h.grp <= cfClassStragetPreflopCommon[3]) {
		bet = BB1;
		tmc = 1;
		tma = 5;
		rra = 0;
		maxBet = MAX(h.stack/10, BB3);
	} else {
		bet = BB1;
		tmc = 0;
		tma = 5;
		rra = 0;
		maxBet = MAX(h.stack/15, BB3);	
	}
	// 在前面控制了最低准入标准
	/*
	} else if (h.grp <= cfClassStragetPreflopCommon[4]) {
		bet = BB1;
		tmc = 0;
		tma = 5;
		rra = 0;
		maxBet = MAX(h.stack/15, BB3);
	} else {
		bet = 0;
		tmc = 0;
		tma = 0;
		rra = 0;
		maxBet = 0;
	}	
	*/
	// 严重错误警告
	if (BB1 < 0 || BB2 < 0 || BB3 < 0) {
		printf("---!!!BBi ERROR!!!---\n");
	}	
	if (h.grp == 8 || h.grp == 9) {
		printf("---!!!GRP ERROR!!!---should:%f < %f---\n", h.grp, cfClassStragetPreflopCommon[4]);
	}

	// 投注
	SetBetOrCall(ai, 80, 20, bet);
	
	// TODO 保护盲注
	/*
	if (maxBet == 0)
		if (ai->game.isSpecialPos == 5) {
		}
		if (ai->game.isSpecialPos == 5) {
		}
	}	
	*/
	// in case 投入太大不应收手 - h.raise_no
	if (IsBet()) {
		if (h.raise_no > 10) {
			SetAllin();
		} else if (h.raise_no > 5) {
			SetBetOrCall(ai, 20, 80, bet);
		}
	}
	
	// tmc - h.raise_no_c
	if ( IsBet() && h.raise_no_c > tmc ) {
		bet = 0;
		if (h.grp <= cfClassStragetPreflopCommon[1]) {
			puts("1");
			SetCallOrFold(ai, 95,  5, bet);
		} else if (h.grp <= cfClassStragetPreflopCommon[2]) {
			puts("2");
			SetCallOrFold(ai, 80, 20, bet);
		} else if (h.grp <= cfClassStragetPreflopCommon[3]) {
			puts("3");
			SetCallOrFold(ai, 20, 80, bet);
		} else if (h.grp <= cfClassStragetPreflopCommon[4]) {
			puts("4");
			SetCallOrFold(ai, 5, 95, bet);			
		} else {
			puts("!!!");
			SetCallOrFold(ai, 0, 100, bet);
		}		
	}
	// rra - h.raise_no
	if ( IsBet() && h.raise_no_c > rra ) {
		if (h.raise_no_c || (h.raise_no_c == 0 && h.raise_no == 1)) {
		//if (ai->action_last.type == ACTION_BET || ai->action_last.type == ACTION_ALL_IN) {
			SetBetOrCall(ai, 10,  90, bet);
		}
	}
	
	//TODO OprActionProtect
	if (IsBet() || IsAllin()) {
		if (h.grp > cfClassStragetPreflopCommon[1]) {
			if (bet < 1.5 * ai->game.raise_amount) {
				SetCall();
				printf("\t\t\t\t[%3.1f:%5d>%5d?NO] bet ---> call\n", h.grp, bet, (int)(1.5 * ai->game.raise_amount));
			}
			if (maxBet < h.current_bet + h.call_amount) {
				SetCallOrFold(ai, 80, 20, 0);
				printf("\t\t\t\t[%3.1f:%5d>%5d?NO] bet ---> call or fold\n", h.grp, maxBet, h.current_bet + h.call_amount);
			} else if (maxBet < h.current_bet + h.call_amount + h.raise_amount) {
				printf("\t\t\t\t[%3.1f:%5d>%5d?NO] bet ---> fold\n", h.grp, maxBet, h.current_bet + h.call_amount + h.raise_amount);
				SetFold();
			}
		}
	}
	if (IsCall()) {
		if (maxBet < h.current_bet + h.call_amount) {
			printf("\t\t\t\t[%3.1f:%5d>%5d?NO] bet ---> fold\n", h.grp, maxBet, h.current_bet + h.call_amount);
			SetFold();
		}		
	}
	// end protect

	tmc = tma;	// 这句并没有什么蛋用
	return 0;
}

static
int IsBetterClassPreflopPwr(int pwr, int class) {	
//	h.pwr >= 10-aggPWCLASSFOUR	//!!!
//	int aggPWCLASS[4]   = {1, 3, 5, 7};
	int aggPWCLASS[4]   = {9, 7, 5, 3};
	if (pwr >= aggPWCLASS[class]) {
		return 1;
	} else {
		return 0;
	}
}

//==========================================================================================================================

//void SetAggressAction(Aggress_t *agg, PokerAI *ai, VarTran_t h, int (*IsBetter)(int pwr, int class));
//void GetAggressLevel(Aggress_t *agg, PokerAI *ai, VarTran_t h);

void MakeDecisionPreflop(PokerAI *ai) {

	VarTran_t h 	= VarTran(ai);
	int       stg   = GetCurrentStraget(h.round);	

	MemcpyAction(&(ai->action_last), &(ai->action));

//	printf("h.grp %f\n", h.grp);
//	rand_cfClassStragetRaiseForStart();
//	printf("【stg no : %d】\n", stg);;
	switch (stg) {
	case 1:		
		StragetPreflopCommon(ai, h, IsMinimunHold_Me);
		break;
	case 2:
		StragetPreflopCommon(ai, h, IsMinimunHold_Mofang);
		break;
	default:
		StragetPreflopCommon(ai, h, IsMinimunHold_Me);
		break;
	}
		
	OprBeforAgg(ai);
	
	Aggress_t agg;	
	SetAggressStruct(&agg, 0);
	GetAggressLevel(&agg, ai, h);
	SetAggressAction(&agg, ai, h, IsBetterClassPreflopPwr);
	
	RecordStat(ai);	// always last
	
	//h.my_pos = agg.my_pos;
	PrintDebugAI(ai, h, (h.grp <= cfClassStragetPreflopCommon[4]), 0);	//(h.grp<=7.0)
}


