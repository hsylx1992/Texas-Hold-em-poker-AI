#include "pokerai.h"
#include "pokerai_aggress.h"

//#include "pokerai_flop.h"


// 配置
//int cfClassStragetRaiseForStart_len = 3;	//三级 [1] [2] [3]
//int cfClassStragetRaiseForStart[] = {-1, 1, 1, 6, -1};



//static int is_print_one_time_info = 1;
//==========================================================================================================================

static
int GetFlopStraget(int round) {
	
	int stg = 1;
	if (round <= myrand(90,100)) {
		stg = 1;
	} else {
		stg = -1;
	}
	return stg;
}

//==========================================================================================================================
#if 0
static 
int IsBetterClassFlopWinprob(int pwr, int class) {	
	int aggWinprobClass[5]   = {100, 8, 7.7, 7, 6};
	if (pwr >= aggWinprobClass[class]) {
		return 1;
	} else {
		return 0;
	}
}
#endif
/*
static
int StackProtection(PokerAI *ai, VarTran_t h, int wpBet) {
}
*/

static
void StragetFlopCommon(PokerAI *ai, VarTran_t h) {
    double winprob = ai->action.winprob;
    double expectedgain = ai->action.expectedgain;

    int randnum = rand() % 100;
    int maxbet = (int)(MAX((ai->game.stack / 2.5), 10*h.BB) - (randnum / 2));
    
	maxbet = MIN(maxbet, ai->game.current_pot);
	
	maxbet -= ai->game.call_amount;
	
    //Don't bet too much on a bluff
    int bluffbet = rand()%(1+3*h.BB); //randnum * maxbet / 100 / 2;

    if (expectedgain < 0.8 && winprob < 0.8)
    {
        if (randnum < 95)
        {
            ai->action.type = ACTION_FOLD;
        }
        else
        {
            ai->action.type = ACTION_BET;
            ai->action.bluff = true;
            ai->action.amount = bluffbet;
        }
    }
    else if ((expectedgain < 1.0 && winprob < 0.85) || winprob < 0.1)
    {
        if (randnum < 80)
        {
            ai->action.type = ACTION_FOLD;
        }
        else if (randnum < 5)
        {
            ai->action.type = ACTION_CALL;
            ai->action.bluff = true;
        }
        else
        {
            ai->action.type = ACTION_BET;
            ai->action.bluff = true;
            ai->action.amount = bluffbet;
        }
    }
    else if ((expectedgain < 1.3 && winprob < 0.9) || winprob < 0.5)
    {
        if (randnum < 60 || winprob < 0.5)
        {
            ai->action.type = ACTION_CALL;
            ai->action.bluff = false;
        }
        else
        {
            ai->action.type = ACTION_BET;
            ai->action.bluff = false;
            ai->action.amount = maxbet;
        }
    }
    else if (winprob < 0.95 || ai->game.communitysize < 4)
    {
        if (randnum < 30)
        {
            ai->action.type = ACTION_CALL;
            ai->action.bluff = false;
        }
        else
        {
            ai->action.type = ACTION_BET;
            ai->action.bluff = false;
            ai->action.amount = maxbet;
        }
    }
    else //huge chance of winning, okay to bet more than "maxbet"
    {
        maxbet = (ai->game.stack - ai->game.call_amount) * 9 / 10;
        ai->action.type = ACTION_BET;
        ai->action.bluff = false;
        ai->action.amount = maxbet;
    }

	
	if (ai->action.bluff == true) {
		printf("\t\t\t\t\t\t--- !!! TRY TO BLUFF [%5d] !!! ---\n", bluffbet);
	}	
	if (ai->action.bluff) {
		if (ai->action.type == ACTION_BET) {
			if (h.current_bet < h.stack/10) {
				SetBetOrCall(ai, 20, 80, bluffbet);
			} else {
				SetCallOrFold(ai, 80, 20, 0);
			}
		}
		if (ai->action.type == ACTION_CALL) {
			if (h.current_bet < h.stack/5) {
				SetCallOrFold(ai, 20, 80, 0);
			} else {
				SetFold();
			}
		}
		if (ai->action.type == ACTION_FOLD) {
			ai->action.bluff = false;
			printf("\t\t\t\t\t\t--- !!! STOP   BLUFF [%5d] !!! ---\n", bluffbet);
		}		
	}
    //If our max bet is less than the call amount, just call instead
    if ((ai->action.type == ACTION_BET) && (maxbet < 0))
    {
        ai->action.type = ACTION_CALL;
    }
    if ((ai->action.type == ACTION_BET) && (maxbet < h.raise_amount))
    {
        ai->action.type = ACTION_CALL;
    }   	
	//stack protect && raise jetton

	// 下注
		
		
	// 陷阱


}

void MakeDecisionFlop(PokerAI *ai)
{

	VarTran_t h 	= VarTran(ai);	
	int       stg   = GetFlopStraget(h.round);	

	MemcpyAction(&(ai->action_last), &(ai->action));

	switch (stg) {
	case 1:
		StragetFlopCommon(ai, h);
		break;
	default:
		StragetFlopCommon(ai, h);
		break;
	}    	
	
	/*
    // All in ... !!!!!!
    if (h.wp >= 0.97) {
    	ai->action.type = ACTION_ALL_IN;
    } else if (h.wp >= 0.95 && h.allin_no_bf) {
    	// 如果前面没有人all_in 那么牌不是最牛逼也可以率先all_in
    	ai->action.type = ACTION_ALL_IN;
    }
    */
    // 钱少的时候在preflop阶段all in赢面才大，在这里all in机会很小
    // TODO
/*
	// call的值不能超过最大可下注值，没有下面的判断就可能call all_in 一盘输光
	// 如果money还有不少的时候，不必fold
	// 投入太大的时候，也不可能收手，只能搏一把，也就是说current_bet不大是call转fold的必要条件
	if (h.money < 25*40 && wpBet < 0 && h.current_bet < h.stack/2) {
		SetFold();
	}
*/  
	OprBeforAgg(ai);
	
	//Aggress_t agg;	
	//SetAggressStruct(&agg, 3);
	//GetAggressLevel(&agg, ai, h);
	//SetAggressAction(&agg, ai, h, IsBetterClassFlopWinprob);
    
    RecordStat(ai);

	PrintDebugAI(ai, h, 1, 3);
}


