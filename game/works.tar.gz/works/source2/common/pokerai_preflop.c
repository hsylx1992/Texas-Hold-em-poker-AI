#include "pokerai.h"
#include "pokerai_aggress.h"

//#include "pokerai_preflop.h"


static int last_round_id = 0;
static int anew_round = 0;

// 配置
static float grpclasscommon[] = {-1, 1, 2.4, 3, 4};


//==========================================================================================================================
    
static
int GetCurrentStraget(int round) {
	
	int stg = 1;
	int mod = (int)(round / 60);
	if (mod%2 == 0) {
		stg = 1;
	} else {
		stg = 1;
	}
	return stg;
}

//==========================================================================================================================

static
void set_grpclasscommon(int a1, int a2, int a3, int a4) {
	grpclasscommon[0] = -1;
	grpclasscommon[1] = a1;
	grpclasscommon[2] = a2;
	grpclasscommon[3] = a3;
	grpclasscommon[4] = a4;	
}

static
int IsMinimunHold_Mofang(PokerAI *ai, VarTran_t h) {
	int ret = 0;
	int c1, c2;
	float grp = GetPreflopGroup(ai->game.hand);
	
	if (ai->game.hand[0]>ai->game.hand[1]) {
		c1 = ai->game.hand[0];
		c2 = ai->game.hand[1];
	} else {
		c1 = ai->game.hand[1];
		c2 = ai->game.hand[0];
	}

    int c1val  = (c1 - 1) / 4;
    int c2val  = (c2 - 1) / 4;
    int c1suit = (c1 - 1) % 4;
    int c2suit = (c2 - 1) % 4;    

	if (grp <= 7 && c1val == 12) {
		// 7以上的Ax
		ret = 1;
	}
	if (grp <= 6 && c1val-1 == c2val && c1suit == c2suit) {
		// 6以上cs
		ret = 1;
	}
	if (grp <= 5 && c1val-1 == c2val) {
		// 5以上co
		ret = 1;
	}		
    if (c1val == c2val && c1val >= 7) {
    	// 一对9以上
        ret = 1;
    }          

    return ret;	
}

static
int IsMinimunHold_Me(PokerAI *ai, VarTran_t h) {
	int ret = 0;
	//SB BB的位置好坏需要特殊处理	
	if (ai->game.first_call == 1) {
		if (h.pos_type == POSTYPE_BLIND) {
			ai->game.pos_type = POSTYPE_BACK;
		}		
	} else {
		if (h.pos_type == POSTYPE_BLIND) {
			ai->game.pos_type = POSTYPE_FRONT;
		}
	}
	
	int maxgrp = 1;
	if (h.pos_type == POSTYPE_FRONT) {
		maxgrp = grpclasscommon[2];
	} else if (h.pos_type == POSTYPE_MIDDLE) {
		maxgrp = grpclasscommon[3];		// 一般位置 grp 1 2 3 4
	} else if (h.pos_type == POSTYPE_BACK) {
		maxgrp = grpclasscommon[4];			// 好位置   grp 1 2 3 4 5 6
	} else {
		maxgrp = grpclasscommon[2];			// 坏位置   grp 1 2
	}
			
	if (h.grp <= maxgrp) {
		ret = 1;
	}
	return ret;
}

static
int get_maxbetcommon(PokerAI *ai, VarTran_t h) {
	int maxBet = 0;
	//TODO 
	if (h.noPlaying >= 7) {
		if (h.grp<=grpclasscommon[1]) {
			maxBet = MAX(h.stack/4, h.BB*10);
		} else if (h.grp<=grpclasscommon[2]) {
			maxBet = MIN(h.stack/4, h.BB*5);
		} else if (h.grp<=grpclasscommon[3]) {
			maxBet = h.BB*5;
		} else if (h.grp<=grpclasscommon[4]){
			maxBet = h.BB*3;
		} else {
			maxBet = 0;
			//fold
		}
	} else 	if (h.noPlaying <= 2) {
		//if (h.strong_player) fold;
		if (h.grp<=grpclasscommon[1]) {
			maxBet = h.stack;
		} else if (h.grp<=grpclasscommon[2]) {
			maxBet = MIN(h.stack/2, h.BB*10);
		} else if (h.grp<=grpclasscommon[3]) {
			maxBet = h.BB*5;
		} else if (h.grp<=grpclasscommon[4]){
			maxBet = h.BB*3;
		} else {
			maxBet = 0;
			//fold
		}
	} else {
		if (h.grp<=grpclasscommon[1]) {
			maxBet = MAX(h.stack/2, h.BB*5);
		} else if (h.grp<=grpclasscommon[2]) {
			maxBet = MIN(h.stack/2, h.BB*10);
		} else if (h.grp<=grpclasscommon[3]) {
			maxBet = h.BB*5;
		} else if (h.grp<=grpclasscommon[4]){
			maxBet = h.BB*3;
		} else {
			maxBet = 0;
			//fold
		}
	}
	
	if (h.pv >= 30)	 {
		// 一对A 一对K
		maxBet = h.stack;
	}
	if (maxBet < h.BB*3) {
		maxBet = MAX(h.BB*3, h.stack);
	}
	if (h.stack < maxBet) {
		maxBet = h.stack;
	}
	return maxBet;
}

static
int get_crtbetcommon(PokerAI *ai, VarTran_t h) {
	int crtBet = 0;
	if (h.grp<=grpclasscommon[1]) {
		crtBet = h.BB*2;
	} else if (h.grp<=grpclasscommon[2]) {
		crtBet = h.BB*1;
	} else if (h.grp<=grpclasscommon[3]) {
		crtBet = h.BB*1;
	} else if (h.grp<=grpclasscommon[4]){
		crtBet = h.BB*0.5;
	} else {
		crtBet = -1;
		//fold
	}
	
	if (h.pv >= 30)	 {
		// 一对A 一对K
		crtBet = h.BB*2.5+myrand(1,5);
	}
	
	//随机地让crtBet降到某BB之下
	int rannum = rand()%100;
	if (rannum < 20) {crtBet -= 6;}
	
	return crtBet;
}

static
int StragetPreflopCommon(PokerAI *ai, VarTran_t h, int (*CanEntry)(PokerAI *ai, VarTran_t h)) {
	
	// 设置阈值
	set_grpclasscommon(1,2.2,2.4,2.4);
	if (h.round <= 50 && h.money+h.stack > 2000) {
		if (h.noPlayers <= 4) {
			set_grpclasscommon(2.2,2.4,2.4,3);
		} else if (h.noPlayers <= 6) {
			set_grpclasscommon(2.4,2.4,3,4);
		}
	}
	
	// 是否玩该手牌
	if (!CanEntry(ai, h)) {
		SetFold();
		return -1;
	}
	
	// 最大bet
	int maxBet = get_maxbetcommon(ai, h);
	int crtBet = get_crtbetcommon(ai, h);
	int tmc = 0;//>=h.raise_no_c;
	int rra = 0;//re-raise abalable
		
	// 更新状态
	if (h.grp <= grpclasscommon[1]) {
		tmc = 1;
		rra = 1;
	} else if (h.grp <= grpclasscommon[2]) {
		tmc = 1;
		rra = 1;
	} else if (h.grp <= grpclasscommon[3]) {
		tmc = 1;
		rra = 0;
	} else {
		tmc = 0;
		rra = 0;
	}
	// 严重错误警告
	if (crtBet < 0) {
		printf("---!!!crtBet ERROR!!!---\n");
	}	
	if (h.grp == 8 || h.grp == 9) {
		printf("---!!!GRP ERROR!!!---should:%f < %f---\n", h.grp, grpclasscommon[4]);
	}

	// 投注
	if (maxBet >= h.current_bet + h.call_amount + h.raise_amount) {
		if (crtBet > 0) {
			SetBetOrCall(ai, 90, 10, crtBet);			
		} else if (crtBet == 0) {
			SetCall();
		} else {
			SetCallOrFold(ai, 10, 90, 0);
		}
	} else if (maxBet >= h.current_bet + h.call_amount) {
		SetCall();
	} else {
		//SetFold();
		SetCallOrFold(ai, 10, 90, 0);
	}
	// 可以全跟的状况
	if (IsFold() && maxBet == h.stack) {
		SetBetOrCall(ai, 90, 10, crtBet);
	}
	// 加注上限为1.5*crtBet
	if (IsBet() && h.grp > grpclasscommon[1]) {
		if (crtBet < 1.5 * ai->game.raise_amount) {
			SetBetOrCall(ai, 10, 90, crtBet);
			printf("\t\t\t\t[%3.1f:%5d>%5d?NO] bet ---> call\n", h.grp, crtBet, (int)(1.5 * ai->game.raise_amount));
		}		
	}
	
	// tmc - h.raise_no_c
	// 当前为raise 前面也曾raise，那么当前的raise会使得raise_no_c加一
	if ( IsBet() && ai->game.raise_no > 0 && h.raise_no_c+1 > tmc ) {
		int bet = 0;
		if (h.grp <= grpclasscommon[1]) {
			puts("1");
			SetBetOrCall(ai, 20,  80, bet);
		} else if (h.grp <= grpclasscommon[2]) {
			puts("2");
			SetCall();
		} else if (h.grp <= grpclasscommon[3]) {
			puts("3");
			SetCall();
		} else if (h.grp <= grpclasscommon[4]) {
			puts("4");
			SetCall();			
		} else {
			puts("!!!");
			SetFold();
		}		
	}
	// rra
	// 当前为raise 前面有其他玩家raise，那么当前的raise是re-raise
	if ( IsBet() && h.raise_no_bf > rra ) {
		if (h.raise_no_c || (h.raise_no_c == 0 && h.raise_no == 1)) {
		//if (ai->action_last.type == ACTION_BET || ai->action_last.type == ACTION_ALL_IN) {
			SetBetOrCall(ai, 10,  90, crtBet);
		}
	}
	
	// end protect
	
	return 0;
}

#if 0
static
int IsBetterClassPreflopPwr(int pwr, int class) {	
//	h.pwr >= 10-aggPWCLASSFOUR	//!!!
//	int aggPWCLASS[4]   = {1, 3, 5, 7};
	int aggPWCLASS[4]   = {9, 7, 5, 3};
	if (pwr >= aggPWCLASS[class]) {
		return 1;
	} else {
		return 0;
	}
}
#endif

//==========================================================================================================================

//void SetAggressAction(Aggress_t *agg, PokerAI *ai, VarTran_t h, int (*IsBetter)(int pwr, int class));
//void GetAggressLevel(Aggress_t *agg, PokerAI *ai, VarTran_t h);

void MakeDecisionPreflop(PokerAI *ai) {

	VarTran_t h 	= VarTran(ai);
	int       stg   = GetCurrentStraget(h.round);	//1

	MemcpyAction(&(ai->action_last), &(ai->action));

	if (h.round - last_round_id >= 2) {		
		last_round_id = h.round-1;
		anew_round    = 1;
		if (h.grp <= grpclasscommon[4]) {
			puts("---------------------------------------------------------------------");
		}
	} else {
		anew_round 	  = 0;
	}
	
	switch (stg) {
	case 1:		
		StragetPreflopCommon(ai, h, IsMinimunHold_Me);
		break;
	case 2:
		StragetPreflopCommon(ai, h, IsMinimunHold_Mofang);
		break;
	default:
		StragetPreflopCommon(ai, h, IsMinimunHold_Me);
		break;
	}
		
	OprBeforAgg(ai);
	
	//Aggress_t agg;	
	//SetAggressStruct(&agg, 0);
	//GetAggressLevel(&agg, ai, h);
	//SetAggressAction(&agg, ai, h, IsBetterClassPreflopPwr);
		
	RecordStat(ai);	// always last
	
	PrintDebugAI(ai, h, (h.grp <= grpclasscommon[4]), 0);
}


